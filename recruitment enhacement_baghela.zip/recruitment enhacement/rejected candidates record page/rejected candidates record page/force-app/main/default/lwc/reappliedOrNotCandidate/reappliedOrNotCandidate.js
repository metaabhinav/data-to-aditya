import { LightningElement,wire,api } from 'lwc';
import getAllPreviousApplication from '@salesforce/apex/ReappliedOrNotCandidateController.getAllPreviousApplication';
import noPrevJobApplicationImage from '@salesforce/resourceUrl/noPrevJobApplicationImg'

const columns = [
    { label: 'Job Application ID', fieldName: 'JobApplicationId', type: 'url', typeAttributes: { label: { fieldName: 'Name' }, target: '_blank' } },
    { label: 'Position', fieldName: 'Position_Name__c',wrapText: true },
    { label: 'Status', fieldName: 'Status__c',wrapText: true },
    { label: 'Date of the Job Application', fieldName: 'CreatedDate',wrapText: true }
]

export default class ReappliedOrNotCandidate extends LightningElement {
    noPrevJobApplicationImage = noPrevJobApplicationImage;
    @api recordId;
    columns = columns;
    errors;
    previousApplications = [];
    
    @wire(getAllPreviousApplication, {recordId: '$recordId'})
    wireCallBackForGetAllPreviousApplication({ data, error }) {
        // console.log(this.recordId);
        // console.log(data+"data h ye");
        // console.log(JSON.stringify(data)+"error h ye");
        if (data) {
            // console.log(data+'ye data hai');
            let tempRecs = [];
            data.forEach((record) => {
                let tempRec = Object.assign({}, record);
                tempRec.JobApplicationId = '/' + tempRec.Id;
                tempRecs.push(tempRec);
            });
            this.previousApplications = tempRecs;
            if(this.previousApplications.length<2){
                this.previousApplications.length=0;
            }
            this.error = undefined;
            // console.log(JSON.stringify(tempRecs)+"temperory data");
            console.log(JSON.stringify(this.previousApplications)+"original data");
            // console.log(hi);
        }
        else if (error) {
            this.errors = error;
            console.log("error");
            // console.log(getAllRejected.size());
        }
    }
}