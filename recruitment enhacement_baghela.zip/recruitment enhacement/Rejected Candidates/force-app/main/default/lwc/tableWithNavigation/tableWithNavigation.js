import NAME_FIELD from '@salesforce/schema/Candidate__c.Name_of_Employee__c'
import { getFieldValue } from 'lightning/uiRecordApi';
import { LightningElement, track, api } from 'lwc';


export default class TableWithNavigation extends LightningElement {
    @api 
    set totalData(data){
        this.totalDataLocal = data;
        this.navUpdateHandler({detail:{
            start : this.start,
            end : this.end
        }});
    }
    get totalData(){
        return this.totalDataLocal
    }
    @api columns
    @api rows = 3
    @api showSearch = false
    
    @track totalDataLocal = []

    start = 0
    end = this.rows
    visibleData = []


    navUpdateHandler(event) {
        this.start = event.detail.start;
        this.end = event.detail.end;
        this.visibleData = this.totalData.slice(this.start, this.end);
    }


    handleSearch(event) {
        const searchKey = event.target.value.toLowerCase();
        if (searchKey) {
            console.log(searchKey);
            this.visibleData = this.totalData;
            if (this.totalData) {
                let searchRecords = [];
                for (let record of this.totalData) {
                    let strVal = getFieldValue(record, NAME_FIELD).Name_of_Employee__c;
                    console.log(JSON.stringify(record.Name_of_Employee__c));
                    if (strVal) {
                        if (strVal.toLowerCase().includes(searchKey)) {
                            searchRecords.push(record);
                        }
                    }
                }
                this.visibleData = searchRecords;
            }
        } else {
            this.visibleData = this.totalData;
        }
    }

    get dataLength() {
        return this.totalData.length;
    }
}

