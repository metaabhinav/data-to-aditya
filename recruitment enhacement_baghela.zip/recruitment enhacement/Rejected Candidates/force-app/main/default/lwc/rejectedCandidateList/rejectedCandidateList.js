import { LightningElement,wire } from 'lwc';
import getAllRejected from '@salesforce/apex/RejectedCandidateController.getAllRejected';

const columns =[
    {label: ' Candidate ID', fieldName:'Candidate_Id',type:'url', typeAttributes: {label: { fieldName: 'Name' },target:'_blank'}},
    {label: 'Candidate Name', fieldName:'Name_of_Employee__c'},
    {label: 'Email',fieldName:'Email__c'},
    {label: 'Status',fieldName:'JobApplicationStatus__c'}
    
]


export default class RejectedCandidateList extends LightningElement {
    columns = columns;
    error;
    rejectedCandidates = [];

    @wire(getAllRejected)
    wireCallBackForGetAllRejectedCandidates({data,error}){
        if(data){
            let tempRecs = [];
            data.forEach((record) =>{
                let tempRec = Object.assign({},record);
                tempRec.Candidate_Id = '/' + tempRec.Id;
                tempRecs.push(tempRec);
            });
            this.rejectedCandidates = tempRecs;
            this.error=undefined;
           
            // console.log(hi);
        }
        else if(error){
            this.errors=error;
            console.log("error");
            // console.log(getAllRejected.size());
        }
    }
 

}